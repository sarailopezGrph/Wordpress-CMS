<?php
/**
 * Close week wrap
 */
if ( 0 === ( $inc + 1 ) % 7 ) {
	echo '</tr>';
}