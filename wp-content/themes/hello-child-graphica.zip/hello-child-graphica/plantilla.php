<?php

//Theme Name: Newspaper Child theme

//Template name: Hoja-plantilla



 get_header(); 

the_content();

get_footer();
?>


